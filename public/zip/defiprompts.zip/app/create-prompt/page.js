/** @format */
import CreatePrompt from '@/components/CreatePrompt';
export default function Create() {
  return (
    <div>
      <CreatePrompt />
    </div>
  );
}
